﻿using System;

namespace LibreriaClases
{
    public class Class1
    {
    }
}
