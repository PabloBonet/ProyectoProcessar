/*
**  Name:   TIMER.C
**  Desc:   main() code and code to operate the Timer-0 interrupts to
**          perform periodic sampling of the barcode pen (joystick port)
*/

#include <stdio.h>
#include <dos.h>
#include "pen.h"


/* Modify SAMPLE_RATE_MULTIPLIER value to adjust for different CPU speeds.
** Use powers-of-two values for best results.  Sample rate will be
** (18.2 * SAMPLE_RATE_MULTIPLIER) Hz.
*/
#define  SAMPLE_RATE_MULTIPLIER   (512)
#define  SAMPLE_PERIOD (65536/SAMPLE_RATE_MULTIPLIER)

#define  BUF_SIZE  (0x1000)

static volatile long SamplingCount;
static volatile int  started;
static volatile int  index;
static volatile barsize_t buffer [BUF_SIZE];
static volatile char buf_full;

static bar;
static PreviousBar;
static InterruptCount;
static RepeatCount;
static handler_installed;
static last_width;

void interrupt increment (void);
void install_handler (void);
void deinstall_handler (void);

typedef void interrupt (*fnptr) (void);
fnptr old_vector;   /* Store existing TIMER0 interrupt handler here */

int ctrl_brk_handler (void)
{
   printf ("Terminating.\n");
   if (handler_installed)
      deinstall_handler();
   return 0;
}

int main (void)

{
char str[100];
int stop;
long count;
int barcount;
int i;
int  old_statregA;
int  old_statregB;
int  rc;
int  ScanGood;

   handler_installed = 0;
   ctrlbrk (ctrl_brk_handler);  /* Assure Timer0 will be reset at termination */
   ScanGood = 0;

   while (!ScanGood)
   {
      /* Reset the variables used to fetch barcode samples */
      SamplingCount = 0;
      index = 0;
      buf_full = 0;
      RepeatCount = 0;   /* Keep track of "string" of bars */


      install_handler ();  /* Turn on faster sample rate */

      while (!buf_full)    /* Wait until a scan is retrieved */
         if (kbhit())      /* terminate if keyboard hit */
         {
            deinstall_handler();
            return 0;
         }

      deinstall_handler ();  /* Turn off fast sample rate to speed up computing */

      if (index == 0)
         continue;

      barcount =index;

      /* Check if the scanned sample is a good barcode */
      rc=analyze_c39 (buffer+1, barcount, str);        /* Is it Code 39? */
      if (rc == -1)
         rc = analyze_i25 (buffer+1, barcount, str);   /* Is it Int 2 of 5? */
      if (rc == 0) {
         printf ("%s",str);
         ScanGood = 1;
      }
      /* Otherwise, check if there was "activity"; if so, then signal
      ** that a "bad read" occured */
      else
         if (index > 8)
            putch ('.');
   } /* end-while (!ScanGood) */
   printf ("\n");
   return 0;
}


/*
**  Func: install_handler
**  Desc: installs Timer0 interrupt handler and changes Timer0 timing
**        rate to fire off a much higher number of interrupts per second
*/

void install_handler (void)
{
   old_vector = getvect (8);
   setvect (8, increment);
   handler_installed = 1;

   disable ();
   outportb (0x43, 0x36);       // 16 bit timer count
   outportb (0x40, (SAMPLE_PERIOD%256));  // Low byte
   outportb (0x40, (SAMPLE_PERIOD/256));  // High byte
   enable ();
   return;
}



/*
**  Func: deinstall_handler
**  Desc: Restores old timer-interrupt vector and resets Timer0 to
**        DOS's 18.2 Hz rate.
*/
void deinstall_handler (void)
{
   setvect (8, old_vector);
   disable ();
   outportb (0x43, 0x36);         // Restore original 16 bit timer count
   outportb (0x40, (65536%256));  // Low byte
   outportb (0x40, (65536/256));  // High byte
   enable ();

   return;
}


/*  Func: increment   (interrupt)
**  Desc: This function gets called every time the timer0 interrupt is
**        fired off.   The sampling starts when a bar is detected
**        and keeps going until the buffer is full or until what
**        looks like a quietzone occurs
*/

void interrupt increment (void)
{
   /* The the barcode-pen signal (via Joystick-port, button 0) */
   bar = inportb (0x201);
   bar = bar & 0x10;

   if (started || bar )
   {
      RepeatCount++;

      /* Is the buffer full?   Are the bars too "wide"? */
      if ( index > (BUF_SIZE-2)
	  || RepeatCount > (SAMPLE_RATE_MULTIPLIER / 2))
      {
	 buffer[index] = RepeatCount;  // Record the size of the last bar
	 buf_full = 1;
      }

      /* Black/white Transition edge? */
      if (bar != PreviousBar)
      {
	 buffer[index++] = RepeatCount;    /* Record the size of the last bar */
	 if ((RepeatCount > last_width * 5) && (index > 6))
	     buf_full = 1;
	 last_width = RepeatCount;
	 RepeatCount = 0;
      }
      started = 1;
      SamplingCount++;
   }
   PreviousBar = bar;

   /* Check to see if it's time to fire off the 18.2 Hz interrupt handler */
   if (!InterruptCount)
      old_vector ();      /* Let default handler finish off the interrupt */
   else
      outportb (0x20, 0x20);  /* Otherwise, we issue the End-Of-Interrupt */
   InterruptCount++;
   InterruptCount = InterruptCount % SAMPLE_RATE_MULTIPLIER;

   return;
}

