/*  Copyright (C) 1993, 1994 by Joseph Chiu, All Rights Reserved  */

/*   ANALYZ39.C -   Analyze bar-size array to extract wide/narrow       */


/*   Descr. :   This module is responsible for taking the bar-size
		array and determining whether the bar is wide or
		narrow.   It uses Code 39's bundle-of-10 (actually,
		bundle of 9 plus 1 separator) characteristic to its
		advantage by bundling 10 bars at a time for analysis.
		The threshold for wide/narrow is set at 150% of
		the 'average size' of elements.


     Input  :   bar     processed bar-size array
		count   is the # of bars in the array bar
		string  string where decoded information goes

     Changes:   string  by filling it with the decoded barcode.

     Returns:   # of errors ecountered in decoding.
		-1 if errors encountered.

     Uses   :   Barcode information pattern table


*/


#include "pen.h"
#include "c39.h"
#include <stdio.h>


int packet_c39 (barsize_t *bar, int direction)
{
unsigned long sigma, threshold;
int i, blk, wht, wide_cnt;

   if (direction == 0)
      return -1;


   sigma = 0;

   for (i = 0; i < 9; i++)  /* 9 bars - we skip separaters in our analysis */
   {
      sigma += *bar;
      if (direction > 0)                /* Traverse the array forward */
	bar++;
      else
	bar--;                          /* or backward */
   }

   threshold = sigma/8;   /* Place threshold at 150% nominal element size */

   blk = 0;
   wht = 0;

   wide_cnt = 0;
   for (i = 0; i < 9; i++) /* 9 bars again - we go "the other way" to   */
   {                       /* traverse back to our first bar            */
      if (direction > 0)
	bar--;
      else
	bar++;

      if (*bar > threshold)
      {
	 wide_cnt++;
	 if (i&1)       /* Odd => white */

	    wht = wht | (1u << (i/2));  /* White */
	 else
	    blk = blk | (1u << (i/2));  /* Black */
      }
   }


   if (wide_cnt != 3)
      return -1;

   return ((int)blk<<4)+wht;

}






int resolve_c39 (int ident)
{
int i;

   for (i = 0; i < 44; i++)
      if (ident == c39_table[i].id)
	 return c39_table[i].ch;

   return -1;
}





#define C39_STSP   0x68
#define C39_RSTRSP 0xc1

int analyze_c39 (bar_array_t bar, int count, char *targstr)
{
   int left, right;
   int group;
   int direction;
   int c;
   int i;
   int val;
   int err_cnt;


   if (count % 10)      /* There should be exactly n*10 bars including  */
      return -1;        /* separators and trailing quiet zones          */

   if (count == 0)
      return -1;        /* And there obviously have to be some bars     */

   if (bar == NULL)
      return -1;        /* Make sure we are given a bar array */


   /* First we need to find st/sp and determine orientation of our data */
   left = packet_c39 (bar+0, 1); /* Start with "leftmost" sample, fwd direction */
   right = packet_c39 (bar+count-10, 1); /* look at the "rightmost" sample too */


   if (left != right)   /* We didn't get a valid st/sp pair */
      return -1;


   if (left == C39_STSP)        /* Forward - start from left */
   {  group = 0;
      direction = 10;
   }
   else
   if (left == C39_RSTRSP)      /* Backward - start from right */
   {
      group = count -2;         /* right-most bar minus one to exclude */
      direction = -10;          /* the quiet zone */
   }
   else return -1;              /* Not valid st/sp code */

   c = 0;
   err_cnt =0;
   for (i = 0; i < count / 10; i++)
   {
      val = packet_c39 (bar+group, direction);

      val = resolve_c39 (val);


      if (val == -1)            /* Bad character ? */
      {
	 err_cnt ++;
	 val = '?';
      }

      targstr[c++] = val;
      group = group + direction;
   }


   targstr[c++]= '\0';

   return err_cnt;

}
