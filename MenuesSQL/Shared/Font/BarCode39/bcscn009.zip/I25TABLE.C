/*  Copyright (C) 1993, 1994, 1995 by Joseph Chiu, All Rights Reserved  */

/*  I25TABLE.C          Interleaved 2 of 5 decode lookup table  */


#include "i25.h"

i25rslv_t i25_table [10] = {

  {0x06, '0'},
  {0x11, '1'},
  {0x09, '2'},
  {0x18, '3'},
  {0x05, '4'},
  {0x14, '5'},
  {0x0c, '6'},
  {0x03, '7'},
  {0x12, '8'},
  {0x0a, '9'}
};



