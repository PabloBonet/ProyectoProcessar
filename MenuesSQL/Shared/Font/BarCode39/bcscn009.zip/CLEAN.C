/*  Copyright (C) 1993, 1994, 1995 by Joseph Chiu, All Rights Reserved  */

/*    CLEAN.C   -   Clean bar-size array to remove drops/voids    */


/*   Descr. :   This module is responsible for taking the bar-size
		array and discarding any drops/voids that may be
		present.


     Input  :   bar    unprocessed bar-size array
		count  is the size of the array bar

     Changes:   bar    by filling it with bar size after corrections.

     Output :   number of bars in the array after processing.

     Uses   :   N  (Number of Wide elements to Narrow) to influence
		   determination of average bar width.

		(deleted) (Was: X as basis of analysis)


     Modified:
		Added extraneous edges due to presence of quiet
		zone that was inadvertently included.

*/


#include "pen.h"
#include <stdio.h>
#include <math.h>
#include <values.h>


int clean_bars  (bar_array_t bar, int count) {
unsigned long sigma;
unsigned long average;
barsize_t ceiling;

int i, j, w1, w2;


   if (count <1)                /* Are input conditions okay? */
      return -1;

   if (bar == NULL)
      return -1;


   sigma = 0;                    /* calculate "average bar" width */
   for (i = 0; i < count-1; i++) /* exclude "last" which is quiet-zone */
      sigma += bar[i];

   average = (10*sigma/(6+3*N+1)/i); /* 6 narrow, 3 wides, 1 separator */

   ceiling = (average/8);  /* we will decimate bars < 12.5% of nom. size */


/* Here, we look to see if there are "unusually large" white spaces     */
/* (i.e., quiet zones) so that we may remove them                       */
/* There are several possibilities:                                     */
/*                                                                      */
/* 1- there is no extra quiet zones     2- there is an extra quiet zone */
/*                                         on the left side             */
/* 3- there are two extra quiet zones                                   */
/*                                      4- there is an extra quiet zone */
/*                                         on the right side            */



#if 0   /* Removed for expediency */
   for ( i = 1; i < count; i+=2) /* Look at whites only */

#endif



/* Now, we will scan the entire bar-size array and "slide" values over  */
/* voids and drops.   If there are two voids/drops adjacent to each     */
/* other, we consider that as transition noise, and eliminate it        */
/* altogether.  If there is only one void/drop, we consider that a      */
/* glitch-- the glitch is removed, and the 'glitched' bars are fused    */
/* together.    Note that this works even where there are multiple      */
/* void-drops strung together - pairs of transition noise are yanked    */
/* out, leaving either one or zero void/drop after the yank.            */
/* If there is one void at that point, then the "transition noise"      */
/* really turns out to be a _really_ noisy (and long) void/drop         */
/* so we fuse the 'good bars'.  Ideally, I would add additional logic   */
/* to compensate for loss-of-width to a glitched bar                    */

/* We start analyzing at 0, and processing at 0                         */

   i = 0;
   j = 0;


   while (i < count)
   {
      if (bar[i] > ceiling) {   /* This bar is okay - keep processing */
	bar[j++] = bar[i++];
	continue;
      }
      else              /* We have a possible glitch or void/drop */
      {
	 if (bar[i+1] <= ceiling)       /* looks like transition noise */
	 {
	    i += 2;     /* We skip over noise and continue analysis */
	 }
	 else                           /* looks like a void/drop         */
	 {
	    if (j > 0)
	    {  if (bar[j+1] < BS_MAX - bar[j-1])
		  bar[j-1] += bar[j+1];            /* Pull together */
	       else
		  bar[j-1] = BS_MAX;    /* Special case when "too big" */
	       i = i+2; /* increment analysis past void & 'fused' bar  */
	       /* j remains same because we 'fused in place' to prev. bar */
	    }
	    else
	    {
	       i = i+2; /* Special case when start-of-data is glitched */
	       /* j remains same because we 'fused in place' to prev. bar */
	    } /* end else: j>0 (start-edge glitch check) */
	 }  /* end else:  bar[i+1] <= ceiling (transition noise) */
      } /* end else: bar[i] <= ceiling (void/drop-glitch check) */
   } /* end while: (i < count) */

   /* At this point, j points to location _after_ the last valid bar       */
   /* i.e., j contains the number of post-processed bars, so we return it. */

   while (j > 1 && bar[j] == BS_MAX && bar[j-1] == BS_MAX)
     j = j -2;  /* Remove any trailers */

   return j;
}

