/*  Copyright (C) 1993, 1994, 1995 by Joseph Chiu, All Rights Reserved  */

/*   ANALYZ25.C -   Analyze bar-size array to extract data              */


/*   Descr. :   This module is responsible for taking the bar-size
		array and determining whether the bar is wide or
		narrow.   It uses Interleaved 2-of-5's characteristics
		to its advantage by looking for 2-of-5 wide elements
		in the data stream.  'Wide' threshold is set at 150%
		of the 'average size' elements.

     Input  :   bar     processed bar-size array
		count   is the # of bars in the array bar
		string  string where decoded information goes

     Changes:   string  by filling it with the decoded barcode.

     Returns:   # of errors in decoding
		-1 if errors encountered.

     Uses   :   Barcode information pattern table


*/


#include "pen.h"
#include "i25.h"
#include <stdio.h>

int packet_i25 (barsize_t *bar, int direction)
{
unsigned long sigma, threshold;
int i, blk, wht, w_widecnt, b_widecnt;

   if (direction == 0)
      return -1;


   sigma = 0;

   /* We analyze two digits at a time: 5 black + 5 white bars */
   for (i = 0; i < 10; i++)  /* 10 bars - we skip separaters in our analysis */
   {
      sigma += *bar;
      if (direction > 0)                /* Traverse the array forward */
	bar++;
      else
	bar--;                          /* or backward */
   }

   threshold = sigma/9;  /* Place threshold at 155% nominal element size */


   blk = 0;
   wht = 0;

   w_widecnt = 0;
   b_widecnt = 0;

   for (i = 0; i < 10; i++) /* 10 bars again - we go "the other way" to */
   {                       /* traverse back to our first bar            */
      if (direction > 0)
	bar--;
      else
	bar++;

      if (*bar > threshold)
      {
	 if (i&1)       /* Odd => white */
	 {  w_widecnt++;
	    wht = wht | (1u << (i/2));  /* White */
	 }

	 else
	 {  b_widecnt++;
	    blk = blk | (1u << (i/2));  /* Black */
	 }
      }
   }


   if (w_widecnt != 2)
      return -1;
   if (b_widecnt != 2)
      return -1;

   return ((int)blk<<8)+wht;

}






int resolve_i25 (int ident)
{
int i;

   for (i = 0; i < 10; i++)
      if (ident == i25_table[i].id)
	 return i25_table[i].ch;

   return -1;
}






int analyze_i25 (bar_array_t bar, int count, char *targstr)
{
   int left, right;
   int group;
   int direction;
   int c;
   int i;
   int val, c1, c2;     /* Characters determined */
   int err_cnt;


   if ((int)(count-8) % 10)  /* There should be exactly n*10 bars excluding     */
      return -1;        /* start/stop and leading quiet zone            */

   if (count <= 8)
      return -1;        /* And there obviously have to be some bars     */

   if (bar == NULL)
      return -1;        /* Make sure we are given a bar array */


   /* First we need to find st/sp and determine orientation of our data */
   /* Compare the two sides - which is bigger? */
   left  = 10 * bar[2] / (int)(bar[0]+bar[1]);
   right = 10 * bar[count-4] /(int) (bar[count-3]+bar[count-2]);


   if (left < right)    /* Forward - start from left */
   {  group = 4;
      direction = 10;
   }
   else
   if (left > right)    /* Backward - start from right */
   {
      group = count -6;         /* right-most bar minus one to exclude */
      direction = -10;          /* the quiet zone */
   }
   else return -1;              /* Not valid st/sp */

   c = 0;
   err_cnt =0;
   for (i = 0; i < (count-8) / 10; i++)
   {
      val = packet_i25 (bar+group, direction);

      c1 = resolve_i25 (val&0xff);
      c2 = resolve_i25 (val>>8);


      if (c1 == -1)             /* Bad character ? */
      {
	 err_cnt ++;
	 val = '?';
      }

      if (c2 == -1)             /* Bad character ? */
      {
	 err_cnt ++;
	 val = '?';
      }

      targstr[c++] = c1;
      targstr[c++] = c2;
      group = group + direction;
   }


   targstr[c++]= '\0';

   return err_cnt;

}
