*|==============================================================
*|    FoxTray.ocx
*|    A sample ActiveX control: using System Tray icon and menu 
*|    in VFP applications
*|==============================================================

+---------------+
|      File     |
+---------------+
FoxTray.ocx


+---------------+
|  OLE Class    |
+---------------+
FoxTrayCtl.cFoxTray


+---------------+
| Registration  |
+---------------+
REGSVR32 FoxTray.ocx


+---------------+
|  Properties   |
+---------------+
STRING IconSource
Read-write; *.ICO file name

STRING IconTip
Read-write, icon tip text


+---------------+
|    Methods    |
+---------------+
VOID ShowIcon
Shows an icon in the Windows System Tray. Displays ICO file stored in the IconSource property or default application icon.

VOID HideIcon
Hides the icon in the Windows System Tray.

POPUPITEM GetPopupItem (LONG Index)
Returns a reference to the POPUPITEM object, in this version the Index range is from 1 to 5.
Read-write properties for the POPUPITEM object:
   - CHAR caption
   - BOOL separator
   - BOOL enabled
   - BOOL visible


+---------------+
|    Events     |
+---------------+
BeforePopupActivate(BOOL Result)
Occurs after LeftMouseClick on the icon before popup activation. Set Result to false to cancel popup activation.

OnPopupItemSelected(LONG Item, CHAR Caption)
Occurs after a popup item selection. Contains an order -- from 1 to 5 (only 5 items available in this version), and caption for the selected item.


+---------------+
|    Author     |
+---------------+
News2News


+---------------+
|    Links      |
+---------------+
http://www.news2news.com/vfp
http://fox.wikis.com/wc.dll?Wiki~Win32Api_Shell_NotifyIcon~VFP
http://support.microsoft.com/default.aspx?scid=kb;EN-US;Q162613
http://support.microsoft.com/default.aspx?scid=kb;EN-US;Q149276
http://support.microsoft.com/default.aspx?scid=kb;EN-US;Q177095
